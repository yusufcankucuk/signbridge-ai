# SignBridge birleşik 71 sınıflı model kartı

## Model

- Sürüm: `signbridge-unified71-bigru-v0.8.0` · Sözlük: `signbridge71-v1` · Ön işleme: `landmark46-v1`
- Mimari: mevcut AUTSL-20 BiGRU encoder'ının 71 çıktıya genişletilmiş sürümü (ilk 20 indeks korunur)
- Girdi: 60 zaman adımı × 46 landmark × (x, y, maske)
- Genel bağlam: mevcut 20 AUTSL sınıfı
- Belirti bağlamı: 15 belirti avatarı (yeni belirti sınıfları + mevcut `seker`)
- `seker`, belirti ekranında `diabetes` avatarı ve “Şeker hastasıyım” metniyle gösterilir.
- Seçilen tohum: 42 (denenen: 42)

## Ölçümler

- Eski model AUTSL test doğruluğu: 0.8522
- Birleşik model AUTSL test doğruluğu: 0.9371 (fark +0.0849;
  kapı ≥ -0.03: geçti)
- AUTSL `seker`: eski 0.3636, yeni 0.9091,
  belirti bağlamında `seker` seçimi 1.0000
- MEB referanslarında belirti-bağlamı doğruluğu: 1.0000
  (118 video, 418 görünüm:
  mediapipe-holistic-legacy: 64, mediapipe-tasks-web: 354)

MEB değeri bağımsız test değildir. Her yeni sağlık sınıfında yalnız bir resmî referans video
bulunduğundan artırılmış örnekler ve farklı çıkarıcı (eski Holistic / canlı kameradaki MediaPipe Tasks)
görünümleri aynı işaretçinin türevleridir. Ayrıntılar `regression_report.md`
dosyasındadır.

## Kullanım ve güvenlik

Bu model yalnız SignBridge öğrenci MVP'sindeki deneysel, tek-izole-işaret demosu içindir.
Tıbbi tanı koymaz. Kamera sonucu hastaya aday olarak gösterilir ve hasta onayı olmadan doktora
aktarılmaz. 15 belirti avatarının tamamı kamerayla önerilebilir.
Model 46 landmark kullanır; TİD'de anlamı değiştirebilen yüz, baş, göz ve gövde hareketlerini görmez.

MEB videolarının yeniden dağıtımı ve bu videolardan türetilen model ağırlıklarının açık yayımlanması,
kullanım izni doğrulanana kadar yapılmamalıdır. Düşük görünürlüklü MEB kaynakları manifestte
`source_quality_status=needs_review` olarak korunur ve iskelet bindirmesiyle incelenmiştir.
